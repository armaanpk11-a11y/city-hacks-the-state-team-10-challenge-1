# Student Signal — 100 Trinity Place

**Team 10 · CriticalAsset Hackathon · Challenge 2**

---

## Dashboard Name

**Student Signal** — A field-truth capture system for NYC public school facilities

## Target Users

- **Students** — Report issues naturally, get status updates, close the feedback loop
- **Custodians** — Receive pre-structured, AI-enriched work orders with context
- **Facilities Operators** — See patterns, compliance implications, and prioritized actions

---

## Problem Statement

Work orders lack field truth. They capture what someone *managed to type into a system*, not what's actually happening. Students experience facility issues daily — leaks, temperature problems, broken equipment — but have no structured way to report them. By the time information reaches a facilities team, it's:

1. **Delayed** — Hours or days after the issue started
2. **Unstructured** — "Something's leaking" with no location, severity, or asset context
3. **Disconnected** — No link to compliance obligations, historical patterns, or nearby reports
4. **One-way** — Students never learn if their report led to action

**Student Signal** solves this by giving students a fast, natural reporting interface and using AI to structure their observations into actionable facility intelligence.

---

## Data Sources

| Source | What We Use | How |
|--------|-------------|-----|
| **CriticalAsset API** | Work orders, assets, locations, compliance obligations | GraphQL API with OAuth2 Client Credentials |
| **NYC Open Data (311)** | Nearby complaints via Socrata API | REST API filtering by ZIP 10006 |
| **Student Input** | Natural language reports with location and severity context | Frontend form → AI structuring |

---

## AI Tools

**Current Implementation:** Mock AI structuring engine using keyword matching and rule-based classification. This demonstrates the concept and data flow without requiring API keys.

**Production Implementation Would Use:**
- **GPT-4 or Claude** for natural language → structured field extraction
- **System prompt** engineered for facilities management domain
- **Confidence scoring** based on information completeness
- **Few-shot examples** from real student reports

The mock engine classifies into: Plumbing, HVAC, Electrical, Elevator, Fire Safety, Indoor Air Quality, and Structural issues — with severity, urgency, and confidence levels.

---

## 3-Minute Pitch Guide

### Section 1: The Problem (30 seconds)
*"Every day, students at 100 Trinity Place experience facility issues that never make it into a work order. A leak starts at 8 AM — maybe someone tells a custodian at lunch — maybe it gets typed into a system by 3 PM. By then, a puddle became water damage. We're fixing this."*

### Section 2: Live Demo — Signal Intake (30 seconds)
*"A student just types what they're experiencing. No forms, no dropdowns, no training needed. They add their location and tell us if it's still happening. One click."*

### Section 3: AI Structuring (30 seconds)
*"Our AI takes that natural language and extracts everything a facilities manager needs: issue type, severity, urgency, asset category, root cause hypothesis. Each field has a confidence level — Verified means the student said it explicitly, Inferred means we're making a reasonable assumption."*

### Section 4: Public Data Enrichment (30 seconds)
*"We cross-reference NYC 311 data for the same ZIP code. If there are multiple plumbing complaints nearby, that's a signal — maybe it's not just our building, maybe there's a water main issue. This changes how you respond."*

### Section 5: Compliance Integration (30 seconds)
*"Every issue gets mapped to relevant obligations from CriticalAsset. A plumbing report? We surface the backflow prevention testing schedule and LL 152 inspection status. The facilities team sees compliance risk alongside the work order."*

### Section 6: The Output (30 seconds)
*"The final output is a complete action package: cleaned description, severity recommendation, assignment suggestion, missing evidence checklist, and compliance implications. Plus a student-facing message so they know their report mattered."*

---

## Technical Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────────┐
│   Student UI    │────▶│  Express Server  │────▶│  CriticalAsset API  │
│  (index.html)   │◀────│   (server.js)    │◀────│  (GraphQL/OAuth2)   │
└─────────────────┘     └──────────────────┘     └─────────────────────┘
                               │     │
                               │     └──────────▶ ┌─────────────────────┐
                               │                  │  NYC Open Data API  │
                               │                  │  (311 / Socrata)    │
                               └──────────────────┘─────────────────────┘
```

### API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/workorders` | Proxy to CriticalAsset work orders |
| POST | `/api/signal` | AI structuring of student report |
| GET | `/api/enrichment?type=` | NYC 311 data enrichment |
| GET | `/api/obligations` | Compliance obligations |
| POST | `/api/feedback` | Student feedback loop |

---

## Running Locally

```bash
cd challenge2
npm init -y
npm install express dotenv
node server.js
# Open http://localhost:3000
```

---

## Safety Statement

⚠️ **This is a prototype built for demonstration purposes.**

- **Not for production use** without proper security review, authentication, and data validation
- **Not for emergency situations** — life-safety issues must go through 911 and established emergency protocols
- **AI outputs require human review** — all classifications, severity assessments, and recommendations must be verified by qualified facilities personnel before action
- **No PII collection** — this prototype does not collect or store personally identifiable information about students
- **Compliance information is illustrative** — actual obligation dates and requirements must be verified against official records

---

## What Would Be Needed for Real-World Use

### Technical Requirements
- [ ] User authentication (SSO integration with NYC DOE)
- [ ] Real LLM integration (GPT-4/Claude with rate limiting)
- [ ] Database for signal history and feedback tracking
- [ ] Photo/video upload capability
- [ ] Push notifications for status updates
- [ ] Mobile-responsive PWA
- [ ] API rate limiting and security hardening
- [ ] Error monitoring and logging (Sentry, DataDog)

### Operational Requirements
- [ ] Student privacy review (FERPA compliance)
- [ ] Accessibility audit (WCAG 2.1 AA)
- [ ] Integration with existing DOE ticketing systems
- [ ] Training materials for custodial staff
- [ ] Escalation protocols for critical issues
- [ ] SLA definitions for response times
- [ ] Multi-language support (Spanish, Chinese, Arabic, Bengali)

### Data Requirements
- [ ] Historical work order data for AI training
- [ ] Asset inventory integration (real-time)
- [ ] Building floor plans for location mapping
- [ ] Vendor/contractor contact integration
- [ ] Inspection history for compliance scoring

---

## Team 10

Built with CriticalAsset API, NYC Open Data, and the belief that the people who use buildings every day should have a voice in how they're maintained.
