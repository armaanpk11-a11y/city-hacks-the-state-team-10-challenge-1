import dotenv from 'dotenv';
import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(express.json());
app.use(express.static(join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const CA_API_URL = process.env.CA_API_URL || 'https://100trinity.stg.criticalasset.com/api';
const CA_CLIENT_ID = process.env.CA_CLIENT_ID;
const CA_CLIENT_SECRET = process.env.CA_CLIENT_SECRET;

// ─────────────────────────────────────────────────────────────────────────────
// OAuth2 Token Management — Client Credentials Flow
// ─────────────────────────────────────────────────────────────────────────────

let cachedToken = null;
let tokenExpiresAt = 0;

async function getAccessToken() {
  const now = Date.now();
  if (cachedToken && now < tokenExpiresAt - 30000) {
    return cachedToken;
  }

  console.log('[Auth] Requesting new access token via client credentials...');

  const mutation = `
    mutation {
      applicationClientCredentialsToken(
        clientId: "${CA_CLIENT_ID}",
        clientSecret: "${CA_CLIENT_SECRET}"
      ) {
        accessToken
        expiresIn
        tokenType
      }
    }
  `;

  const response = await fetch(CA_API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: mutation }),
  });

  const result = await response.json();

  if (result.errors) {
    console.error('[Auth] Token exchange failed:', result.errors);
    throw new Error('Failed to obtain access token');
  }

  const tokenData = result.data.applicationClientCredentialsToken;
  cachedToken = tokenData.accessToken;
  tokenExpiresAt = now + (tokenData.expiresIn * 1000);

  console.log(`[Auth] Token acquired, expires in ${tokenData.expiresIn}s`);
  return cachedToken;
}

async function graphqlRequest(query, variables = {}) {
  const token = await getAccessToken();

  const response = await fetch(CA_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({ query, variables }),
  });

  const result = await response.json();

  if (result.errors) {
    console.error('[GraphQL] Query errors:', result.errors);
    throw new Error(result.errors[0]?.message || 'GraphQL query failed');
  }

  return result.data;
}

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/workorders — Proxy to CriticalAsset Work Orders
// ─────────────────────────────────────────────────────────────────────────────

app.get('/api/workorders', async (req, res) => {
  try {
    const query = `
      {
        workOrders(limit: 10) {
          totalCount
          nodes {
            id
            title
            description
            severity
            executionPriority
            workOrderType
            workOrderServiceCategory
            startDate
            endDate
            locationAddress
            workOrderStage {
              name
            }
            workOrderAssets {
              asset {
                id
                name
              }
            }
          }
        }
      }
    `;

    const data = await graphqlRequest(query);
    res.json(data.workOrders);
  } catch (error) {
    console.error('[WorkOrders] Error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/signal — Student Signal Intake + AI Structuring
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Mock AI structuring engine.
 * In production, this would call GPT-4 or Claude with a carefully crafted
 * system prompt that instructs the model to extract structured facility
 * management fields from unstructured student reports.
 *
 * Prompt template (for real LLM):
 * """
 * You are a facilities management AI. A student at a NYC public school
 * reported the following issue. Extract structured fields for work order
 * creation. Assign confidence levels: Verified (directly stated),
 * Likely (strongly implied), Inferred (reasonable assumption),
 * Missing (not enough info), Needs Inspection (requires physical check).
 * """
 */
function mockAIStructure(text, location, stillHappening, disruption) {
  const lower = text.toLowerCase();

  // Keyword-based issue type detection
  let issueType = 'General Maintenance';
  let assetCategory = 'Building Systems';
  let likelyRootCause = 'Wear and degradation over time';
  let recommendedAction = 'Schedule inspection and maintenance';
  let severity = 'Medium';
  let urgency = 'Standard';

  if (lower.includes('water') || lower.includes('leak') || lower.includes('drip') || lower.includes('flood') || lower.includes('pipe') || lower.includes('plumbing')) {
    issueType = 'Plumbing / Water Intrusion';
    assetCategory = 'Plumbing Systems';
    likelyRootCause = 'Pipe degradation, joint failure, or backflow issue';
    recommendedAction = 'Dispatch plumber for inspection; check backflow preventers';
    severity = stillHappening ? 'Critical' : 'High';
    urgency = stillHappening ? 'Emergency' : 'Urgent';
  } else if (lower.includes('heat') || lower.includes('cold') || lower.includes('hvac') || lower.includes('air') || lower.includes('temperature') || lower.includes('freezing')) {
    issueType = 'HVAC / Climate Control';
    assetCategory = 'HVAC Systems';
    likelyRootCause = 'Thermostat malfunction, duct blockage, or compressor failure';
    recommendedAction = 'Check thermostat settings and inspect HVAC unit';
    severity = disruption >= 4 ? 'High' : 'Medium';
    urgency = disruption >= 4 ? 'Urgent' : 'Standard';
  } else if (lower.includes('electric') || lower.includes('power') || lower.includes('outlet') || lower.includes('light') || lower.includes('spark') || lower.includes('dark')) {
    issueType = 'Electrical';
    assetCategory = 'Electrical Systems';
    likelyRootCause = 'Circuit overload, fixture failure, or wiring degradation';
    recommendedAction = 'De-energize affected circuit; dispatch licensed electrician';
    severity = lower.includes('spark') ? 'Critical' : 'High';
    urgency = lower.includes('spark') ? 'Emergency' : 'Urgent';
  } else if (lower.includes('elevator') || lower.includes('lift') || lower.includes('stuck')) {
    issueType = 'Elevator / Vertical Transport';
    assetCategory = 'Elevator Systems';
    likelyRootCause = 'Mechanical failure or sensor malfunction';
    recommendedAction = 'Contact elevator service provider; check safety interlocks';
    severity = 'Critical';
    urgency = 'Emergency';
  } else if (lower.includes('fire') || lower.includes('smoke') || lower.includes('alarm') || lower.includes('sprinkler')) {
    issueType = 'Fire Safety';
    assetCategory = 'Fire Protection Systems';
    likelyRootCause = 'Detector malfunction, suppression system issue, or actual fire event';
    recommendedAction = 'Evacuate if active; inspect fire safety systems immediately';
    severity = 'Critical';
    urgency = 'Emergency';
  } else if (lower.includes('mold') || lower.includes('smell') || lower.includes('odor') || lower.includes('gas') || lower.includes('fume')) {
    issueType = 'Indoor Air Quality / Hazmat';
    assetCategory = 'Environmental Systems';
    likelyRootCause = 'Moisture intrusion, ventilation failure, or chemical release';
    recommendedAction = 'Ventilate area; test air quality; identify source';
    severity = 'High';
    urgency = 'Urgent';
  } else if (lower.includes('door') || lower.includes('lock') || lower.includes('window') || lower.includes('broken') || lower.includes('crack')) {
    issueType = 'Structural / Access';
    assetCategory = 'Building Envelope';
    likelyRootCause = 'Physical damage or hardware failure';
    recommendedAction = 'Secure area and schedule repair';
    severity = 'Medium';
    urgency = 'Standard';
  }

  // Adjust based on disruption level
  if (disruption >= 4 && severity === 'Medium') severity = 'High';
  if (disruption >= 5 && urgency === 'Standard') urgency = 'Urgent';

  // Confidence assignments
  const confidenceMap = {
    issueType: lower.length > 20 ? 'Likely' : 'Inferred',
    location: location ? 'Verified' : 'Missing',
    severity: stillHappening !== undefined ? 'Likely' : 'Inferred',
    urgency: disruption ? 'Likely' : 'Inferred',
    assetCategory: 'Inferred',
    likelyRootCause: 'Inferred',
    missingEvidence: 'Needs Inspection',
    recommendedAction: 'Likely',
  };

  // Determine missing evidence
  const missingEvidence = [];
  if (!lower.includes('photo') && !lower.includes('picture')) missingEvidence.push('No photographic evidence');
  if (!lower.match(/\d+/)) missingEvidence.push('No specific measurements or quantities');
  if (!lower.includes('when') && !lower.includes('started') && !lower.includes('since')) missingEvidence.push('Onset time unclear');
  if (!lower.includes('other') && !lower.includes('multiple') && !lower.includes('people')) missingEvidence.push('Number of affected occupants unknown');

  // Operational implication
  let operationalImplication = 'May affect building operations and occupant comfort.';
  if (severity === 'Critical') {
    operationalImplication = 'Immediate threat to occupant safety or building integrity. May require partial evacuation or space closure.';
  } else if (severity === 'High') {
    operationalImplication = 'Significant disruption to building function. Requires priority attention within 24 hours.';
  }

  return {
    issueType,
    location: location || 'Not specified',
    severity,
    urgency,
    assetCategory,
    likelyRootCause,
    missingEvidence,
    operationalImplication,
    recommendedAction,
    confidence: confidenceMap,
    studentMessage: text,
    stillHappening,
    disruptionLevel: disruption,
    processedAt: new Date().toISOString(),
  };
}

app.post('/api/signal', (req, res) => {
  const { text, location, stillHappening, disruption } = req.body;

  if (!text || text.trim().length === 0) {
    return res.status(400).json({ error: 'Signal text is required' });
  }

  // In production: const analysis = await callLLM(text, location, stillHappening, disruption);
  const analysis = mockAIStructure(text, location, stillHappening, disruption);

  res.json(analysis);
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/enrichment — NYC 311 Open Data Enrichment
// ─────────────────────────────────────────────────────────────────────────────

app.get('/api/enrichment', async (req, res) => {
  const { type } = req.query;

  // Map issue types to NYC 311 complaint types
  const complaintTypeMap = {
    plumbing: 'PLUMBING',
    water: 'WATER SYSTEM',
    hvac: 'HEATING',
    electrical: 'ELECTRIC',
    elevator: 'ELEVATOR',
    fire: 'FIRE SAFETY DIRECTOR',
    mold: 'INDOOR AIR QUALITY',
    structural: 'MAINTENANCE OR FACILITY',
    general: 'MAINTENANCE OR FACILITY',
  };

  const issueKey = (type || 'general').toLowerCase().split('/')[0].split(' ')[0];
  const complaintType = complaintTypeMap[issueKey] || 'MAINTENANCE OR FACILITY';

  try {
    const baseUrl = 'https://data.cityofnewyork.us/resource/erm2-nwe9.json';
    const whereClause = `incident_zip='10006' AND upper(complaint_type) LIKE '%${complaintType}%'`;
    const params = new URLSearchParams({
      '$where': whereClause,
      '$order': 'created_date DESC',
      '$limit': '5',
    });

    const response = await fetch(`${baseUrl}?${params.toString()}`);
    const complaints = await response.json();

    // Build operational summary
    const totalComplaints = complaints.length;
    const recentDays = totalComplaints > 0 ? Math.ceil(
      (Date.now() - new Date(complaints[complaints.length - 1]?.created_date).getTime()) / (1000 * 60 * 60 * 24)
    ) : 0;

    const summary = {
      complaintType,
      zipCode: '10006',
      totalFound: totalComplaints,
      timeSpan: recentDays > 0 ? `Last ${recentDays} days` : 'No recent data',
      operationalMeaning: totalComplaints >= 3
        ? `High density of ${complaintType.toLowerCase()} complaints in this zip code suggests a systemic or area-wide issue. This strengthens the case for proactive maintenance scheduling.`
        : totalComplaints >= 1
          ? `Some ${complaintType.toLowerCase()} activity in this area. The reported issue may be isolated but warrants inspection.`
          : `No recent ${complaintType.toLowerCase()} complaints nearby. This issue may be building-specific rather than area-wide.`,
      complaints: complaints.map(c => ({
        date: c.created_date,
        type: c.complaint_type,
        descriptor: c.descriptor,
        status: c.status,
        address: c.incident_address,
        resolution: c.resolution_description || 'Pending',
      })),
    };

    res.json(summary);
  } catch (error) {
    console.error('[Enrichment] Error fetching 311 data:', error.message);
    res.status(500).json({ error: 'Failed to fetch NYC 311 data', details: error.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/obligations — Compliance Obligations from CriticalAsset
// ─────────────────────────────────────────────────────────────────────────────

app.get('/api/obligations', (req, res) => {
  const obligations = [
    {
      id: 'OBL-001',
      title: 'Annual Backflow Prevention Device Testing',
      category: 'Plumbing',
      authority: 'NYC DEP',
      frequency: 'Annual',
      description: 'All backflow prevention devices must be tested annually by a licensed tester. Results filed with DEP within 30 days.',
      relevantAssets: ['Cross-connection control valves', 'Reduced pressure zone assemblies'],
      penalty: 'Violation notice + potential water service interruption',
      nextDue: '2026-09-15',
    },
    {
      id: 'OBL-002',
      title: 'Plumbing System Inspection (LL 152)',
      category: 'Plumbing',
      authority: 'NYC DOB',
      frequency: 'Every 5 years',
      description: 'Gas piping systems in buildings must be periodically inspected by a licensed master plumber per Local Law 152.',
      relevantAssets: ['Gas piping', 'Supply lines', 'Shut-off valves'],
      penalty: 'Civil penalties up to $10,000 per violation',
      nextDue: '2027-01-01',
    },
    {
      id: 'OBL-003',
      title: 'Fire Alarm System Inspection',
      category: 'Fire Safety',
      authority: 'FDNY',
      frequency: 'Semi-annual',
      description: 'Fire alarm systems must be inspected and tested every 6 months. Deficiencies must be corrected within 30 days.',
      relevantAssets: ['Smoke detectors', 'Pull stations', 'Annunciator panels', 'Sprinkler heads'],
      penalty: 'FDNY violation + potential building closure order',
      nextDue: '2026-07-01',
    },
    {
      id: 'OBL-004',
      title: 'HVAC Preventive Maintenance (LL 95/LL 97)',
      category: 'HVAC',
      authority: 'NYC DOB / DEP',
      frequency: 'Quarterly',
      description: 'HVAC systems must be maintained to meet energy efficiency and emissions targets. Filter changes, coil cleaning, and refrigerant checks required.',
      relevantAssets: ['Air handling units', 'Rooftop units', 'Chillers', 'Boilers'],
      penalty: 'Carbon penalties under LL 97; DOB violations for non-compliance',
      nextDue: '2026-06-30',
    },
    {
      id: 'OBL-005',
      title: 'Elevator Periodic Inspection (Category 1 & 5)',
      category: 'Elevator',
      authority: 'NYC DOB',
      frequency: 'Annual (Cat 1) / Every 5 years (Cat 5)',
      description: 'Elevators must undergo annual safety inspections and 5-year comprehensive tests. Out-of-service elevators must be reported within 24 hours.',
      relevantAssets: ['Passenger elevators', 'Freight elevators', 'Escalators'],
      penalty: 'DOB violation + potential stop-use order; fines up to $25,000',
      nextDue: '2026-08-01',
    },
    {
      id: 'OBL-006',
      title: 'Electrical System Inspection (LL 62)',
      category: 'Electrical',
      authority: 'NYC DOB',
      frequency: 'Every 5 years',
      description: 'Electrical systems in buildings over 6 stories must be inspected every 5 years by a licensed electrician. Report filed with DOB.',
      relevantAssets: ['Main switchgear', 'Distribution panels', 'Emergency lighting', 'Generator'],
      penalty: 'Civil penalties + mandatory reinspection at owner cost',
      nextDue: '2028-03-01',
    },
  ];

  const { category } = req.query;
  if (category) {
    const filtered = obligations.filter(o =>
      o.category.toLowerCase().includes(category.toLowerCase())
    );
    return res.json(filtered);
  }

  res.json(obligations);
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/feedback — Student Feedback Loop
// ─────────────────────────────────────────────────────────────────────────────

app.post('/api/feedback', (req, res) => {
  const { workOrderId, status, notes } = req.body;

  if (!status || !['fixed', 'still_happening', 'worse'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status. Must be: fixed, still_happening, or worse' });
  }

  // In production: store in database, update work order status, trigger escalation if "worse"
  const response = {
    received: true,
    timestamp: new Date().toISOString(),
    workOrderId: workOrderId || 'unlinked',
    status,
    notes: notes || '',
    message: status === 'fixed'
      ? 'Thank you! We\'re glad the issue was resolved. Your feedback helps us track response quality.'
      : status === 'still_happening'
        ? 'Thank you for the update. This has been flagged for follow-up. A facilities team member will check within 24 hours.'
        : 'This has been escalated as a priority issue. A supervisor has been notified and will respond within 4 hours.',
    escalated: status === 'worse',
    nextAction: status === 'worse' ? 'Supervisor notification sent' : 'Logged for quality tracking',
  };

  console.log(`[Feedback] ${status.toUpperCase()} — WO: ${workOrderId || 'none'} — ${notes || 'no notes'}`);
  res.json(response);
});

// ─────────────────────────────────────────────────────────────────────────────
// Start Server
// ─────────────────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`\n🏫 Student Signal — 100 Trinity Place`);
  console.log(`   Server running on http://localhost:${PORT}`);
  console.log(`   API URL: ${CA_API_URL}`);
  console.log(`   Client ID: ${CA_CLIENT_ID ? '✓ loaded' : '✗ missing'}`);
  console.log(`   Client Secret: ${CA_CLIENT_SECRET ? '✓ loaded' : '✗ missing'}\n`);
});
